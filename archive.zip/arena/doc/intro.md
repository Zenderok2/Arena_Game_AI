# Introduction to arena

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
