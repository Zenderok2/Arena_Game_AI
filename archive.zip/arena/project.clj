(defproject arena "2.0.0-BOSS"
  :description "Multiplayer arena game with AI boss in Clojure"
  :url "https://github.com/your-username/arena-game"
  :license {:name "EPL-2.0 OR GPL-2.0-or-later WITH Classpath-exception-2.0"
            :url "https://www.eclipse.org/legal/epl-2.0/"}

  :dependencies
  [[org.clojure/clojure "1.11.1"]
   [org.clojure/core.async "1.5.648"]
   [http-kit "2.5.3"]
   [cheshire "5.10.0"]
   [quil "3.1.0"]]

  :main arena.core
  :target-path "target/%s"
  :resource-paths ["resources"]

  :jvm-opts ["-Xmx512m"
             "-XX:+UseG1GC"
             "-Dclojure.compiler.direct-linking=true"]

  :aot [arena.core]

  :profiles
  {:uberjar {:aot :all
             :uberjar-name "arena-game-standalone.jar"}
   :dev {:dependencies [[org.clojure/tools.namespace "1.3.0"]]}}

  :aliases
  {"server" ["run" "server"]
   "client" ["run" "client"]
   "build-uberjar" ["clean" "uberjar"]
   "test-all" ["do" "clean" "test"]})
