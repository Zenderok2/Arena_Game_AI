(ns arena.client.websocket
  (:require [cheshire.core :as json]
            [arena.client.state :as state])
  (:import (java.net URI)
           (java.net.http HttpClient WebSocket WebSocket$Listener)
           (java.nio CharBuffer)
           (java.util.concurrent CompletableFuture)
           (java.util Timer TimerTask)))

;; Объявляем функции заранее для решения циклических зависимостей
(declare connect attempt-reconnect reconnect)

(defonce ws-atom (atom nil))
(defonce ping-timer (atom nil))
(defonce message-buffer (atom ""))
(defonce server-url (atom "ws://localhost:8080"))
(defonce reconnect-attempts (atom 0))
(defonce max-reconnect-attempts 5)
(defonce last-ping-time (atom 0))
(defonce network-latency (atom 0))

(defn set-server-url! [url]
  (reset! server-url (str "ws://" url ":8080")))

(defn safe-send [data]
  (when-let [ws @ws-atom]
    (future
      (try
        (.sendText ws (json/generate-string data) true)
        (catch Exception e
          (println "WebSocket send error:" (.getMessage e)))))))

(defn send-ping []
  (reset! last-ping-time (System/currentTimeMillis))
  (safe-send {:type "ping" :timestamp @last-ping-time}))

(defn send-move [x y]
  (safe-send {:type "move" :x x :y y}))

(defn send-shoot [dx dy]
  (safe-send {:type "shoot" :dx dx :dy dy}))

(defn calculate-latency [ping-time]
  (when (pos? ping-time)
    (let [latency (- (System/currentTimeMillis) ping-time)]
      (reset! network-latency latency)
      latency)))

(defn start-ping-timer []
  (let [timer (Timer. true)
        task (proxy [TimerTask] []
               (run [] (send-ping)))]
    (.scheduleAtFixedRate timer task 0 10000) ; Ping every 10 seconds
    (reset! ping-timer timer)))

(defn stop-ping-timer []
  (when-let [timer @ping-timer]
    (.cancel timer)
    (reset! ping-timer nil)))

(defn buffer-to-string [buffer]
  (if (instance? CharBuffer buffer)
    (.toString buffer)
    (str buffer)))

(defn try-parse-json [json-str]
  (try
    (json/parse-string json-str true)
    (catch Exception e
      (println "JSON parse error:" (.getMessage e) "for message:" (subs json-str 0 (min 100 (count json-str))))
      nil)))

(defn handle-boss-state [players]
  "Обработка специальной логики для босса"
  (when-let [boss (get players "boss")]  ; Ищем босса по строковому ключу
    (state/add-debug-message (str "Boss HP: " (:hp boss) "/1000"))
    
    ;; Уведомление о низком HP босса
    (when (< (:hp boss) 300)
      (state/add-debug-message "BOSS IS LOW ON HEALTH!"))))

(defn handle-complete-message [msg-str]
  (try
    (let [parsed-msg (try-parse-json msg-str)]
      (state/increment-packets-received)

      (if-not parsed-msg
        (println "Failed to parse JSON message")

        (let [msg-type (:type parsed-msg)]
          (case msg-type

            ;; =========================
            ;; INIT — первое подключение
            ;; =========================
            "init"
            (let [self-id (:self-id parsed-msg)
                  players (:players parsed-msg)]
              (println "✅ Connected to server, player ID:" self-id)

              ;; self-id всегда строка
              (state/set-self-id (keyword self-id))

              ;; гарантированно оживляем себя
              (state/set-players
               (update players (keyword self-id)
                       (fn [player]
                         (-> (or player {})
                             (assoc :dead false)))))

              (reset! reconnect-attempts 0)

              (when (get players "boss")
                (println "🔥 Boss detected in the arena!"))

              (println "👥 Initial players:" (count players))

              ;; Немедленное обновление статистики
              (state/update-derived-stats)
              
              ;; Добавляем небольшую задержку для полной инициализации
              (future
                (Thread/sleep 50)
                (state/update-derived-stats)))

            ;; =========================
            ;; STATE — основной апдейт
            ;; =========================
            "state"
            (do
              (state/update-game-state
               {:players (:players parsed-msg)
                :bullets (:bullets parsed-msg)
                :bonuses (:bonuses parsed-msg)})

              (handle-boss-state (:players parsed-msg)))

            ;; =========================
            ;; PLAYER JOINED
            ;; =========================
            "player-joined"
            (let [player-id (:player-id parsed-msg)
                  player-data (:player parsed-msg)]
              (println "🎮 New player joined:" player-id)

              (state/set-players
               (assoc (state/get-players) (keyword player-id) player-data))

              (state/update-derived-stats))

            ;; =========================
            ;; PLAYER LEFT
            ;; =========================
            "player-left"
            (do
              (println "👋 Player left:" (:player-id parsed-msg))

              (state/set-players
               (dissoc (state/get-players) (keyword (:player-id parsed-msg))))

              (state/update-derived-stats))

            ;; =========================
            ;; PONG — latency
            ;; =========================
            "pong"
            (when-let [timestamp (:timestamp parsed-msg)]
              (let [latency (calculate-latency timestamp)]
                (state/update-network-latency latency)
                (state/add-debug-message (str "Ping: " latency "ms"))))

            ;; =========================
            ;; BOSS INFO
            ;; =========================
            "boss-info"
            (do
              (println "🤖 Received boss info")
              (when-let [boss (:boss parsed-msg)]
                (state/add-debug-message
                 (str "Boss spawned with " (:hp boss) " HP"))))

            ;; =========================
            ;; SERVER ERROR
            ;; =========================
            "error"
            (println "❌ Server error:" (:message parsed-msg))

            ;; =========================
            ;; UNKNOWN MESSAGE
            ;; =========================
            (println "⚠️ Unknown message type:"
                     msg-type
                     "content:"
                     (dissoc parsed-msg :type))))))
    (catch Exception e
      (println "❌ Error handling message:" (.getMessage e)))))

(defn handle-server-msg [msg last?]
  (let [msg-str (buffer-to-string msg)]
    (swap! message-buffer str msg-str)
    (when last?
      (let [complete-msg @message-buffer]
        (reset! message-buffer "")
        (handle-complete-message complete-msg)))))

(defn should-reconnect? []
  "Определяет, стоит ли пытаться переподключиться"
  (and (< @reconnect-attempts max-reconnect-attempts)
       (not= (state/get-connection-status) :connected)))

(defn attempt-reconnect []
  "Попытка переподключения с экспоненциальной задержкой"
  (when (should-reconnect?)
    (swap! reconnect-attempts inc)
    (let [attempt @reconnect-attempts
          delay-ms (* 3000 (min attempt 5))] ; Экспоненциальная задержка до 15 секунд
      (println "🔄 Attempting to reconnect..." attempt "/" max-reconnect-attempts "(waiting" delay-ms "ms)")
      (Thread/sleep delay-ms)
      (connect))))

(defn connect []
  (future
    (try
      (let [client (HttpClient/newHttpClient)
            listener (reify WebSocket$Listener
                       (onOpen [_ ws]
                         (println "✅ WebSocket connection established")
                         (.request ws 1)
                         (reset! ws-atom ws)
                         (state/set-connection-status :connected)
                         (reset! message-buffer "")
                         (reset! reconnect-attempts 0)
                         (start-ping-timer)
                         
                         ;; Не обновляем статистику здесь - дождемся init сообщения
                         (CompletableFuture/completedFuture nil))
                       
                       (onText [_ ws msg last?]
                         (try
                           (handle-server-msg msg last?)
                           (catch Exception e
                             (println "❌ Error processing message:" (.getMessage e))
                             (state/add-debug-message (str "Message processing error: " (.getMessage e)))))
                         (.request ws 1)
                         (CompletableFuture/completedFuture nil))
                       
                       (onError [_ ws err]
                         (println "❌ WebSocket error:" (.getMessage err))
                         (state/set-connection-status :error)
                         (state/add-debug-message (str "WebSocket error: " (.getMessage err)))
                         (CompletableFuture/completedFuture nil))
                       
                       (onClose [_ ws status reason]
                         (println "🔌 WebSocket disconnected:" reason)
                         (reset! ws-atom nil)
                         (state/set-connection-status :disconnected)
                         (reset! message-buffer "")
                         (stop-ping-timer)
                         
                         ;; Автоматическая переподключение
                         (attempt-reconnect)
                         
                         (CompletableFuture/completedFuture nil)))]
        
        (println "🔗 Connecting to:" @server-url)
        (state/set-connection-status :connecting)
        (let [ws-future (.buildAsync (.newWebSocketBuilder client)
                                     (URI/create @server-url) 
                                     listener)]
          (.join ws-future)))
      
      (catch Exception e
        (println "❌ WebSocket connection failed:" (.getMessage e))
        (state/set-connection-status :error)
        (state/add-debug-message (str "Connection failed: " (.getMessage e)))
        
        ;; Повторная попытка подключения
        (attempt-reconnect)))))

(defn disconnect []
  "Явное отключение от сервера"
  (println "🛑 Disconnecting from server...")
  (stop-ping-timer)
  (reset! reconnect-attempts max-reconnect-attempts) ; Предотвращаем авто-переподключение
  (when-let [ws @ws-atom]
    (.sendClose ws 1000 "Client disconnected")
    (reset! ws-atom nil))
  (state/set-connection-status :disconnected))

(defn get-connection-status []
  "Возвращает статус соединения"
  {:connected? (= (state/get-connection-status) :connected)
   :reconnect-attempts @reconnect-attempts
   :max-reconnect-attempts max-reconnect-attempts
   :latency-ms @network-latency
   :server-url @server-url})

(defn reconnect []
  "Принудительное переподключение"
  (println "🔄 Manual reconnection initiated")
  (disconnect)
  (Thread/sleep 1000)
  (connect))

(defn debug-print-state [state-type data]
  (println "=== DEBUG" state-type "===")
  (when data
    (if (map? data)
      (doseq [[k v] data]
        (println (str k ": ") 
                 (if (map? v)
                   (str "{" (count v) " keys}")
                   (if (coll? v)
                     (str "[" (count v) " items]")
                     v))))
      (println "Data:" (type data) (if (coll? data) (count data) data))))
  (println "==================="))